Please note both x86 and x86_64 is present. This will be the last of 32-bit Lemon OS. 
